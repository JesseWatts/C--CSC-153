﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{/**
* 22 Jan 19
* CSC 153
* Jesse Watts
* This program asks the user to enter a person's age and displays
* whether the person is an infant, a child, a teenager, or an adult.
*/
    class Program
    {
        static void Main(string[] args)
        {


            // Declare a int variable to hold a person's age.
            double userAge;

            // Get age from user.
            Console.Write("Enter an age: ");
            string input = Console.ReadLine();

            // Use if else statements to determine the classification based on the age entered.
            if (double.TryParse(input, out userAge))
            {
                if (userAge < 1)
                {
                    Console.WriteLine("You are an infant.");
                }
                else if (userAge < 13)
                {
                    Console.WriteLine("You are a child.");
                }
                else if (userAge < 20)
                {
                    Console.WriteLine("You are a teen.");
                }
                else
                {
                    Console.WriteLine("You are an adult");
                }
            }
            else
            {
                Console.WriteLine("Not a valid age!");
            }


            Console.ReadLine();


        }
    }
}
