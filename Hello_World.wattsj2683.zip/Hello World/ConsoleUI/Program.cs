﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
 * 16 Jan 2019
 * CSC-153
 * Watts, Jesse
 * Hello World introduction
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World.  My name is Jesse Watts.");
            Console.WriteLine("");
            Console.WriteLine("I'd like to learn more about programming in general and add this knowledge to my skill set.");
            Console.WriteLine("");
            Console.WriteLine("I've taken Python, Java and Adv Java, and I'm currently taking Adv Python.");
            Console.WriteLine("");
            Console.WriteLine("The subjects in the list were gone over briefly");
            Console.WriteLine("but I don't think I quite grasped them.");
            Console.WriteLine("");
            Console.WriteLine("I still struggle with breaking down a programming problem and I don't know what an array is or how to use it properly.");
            Console.WriteLine("");
            Console.WriteLine("I've heard from other students that this class will help to explain Java better.");
            Console.ReadLine();
        }
    }
}
